bower-angular-cookies
=====================

angular-cookies bower repo