bower-angular-sanitize
======================

angular-sanitize bower repo